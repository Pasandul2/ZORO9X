from license_manager import LicenseService


def main():
    license_service = LicenseService()

    key = input('Enter activation key (or leave blank to skip): ').strip()
    if key:
        try:
            state = license_service.activate(key)
            print('Activation success. Expires at:', state.get('expires_at'))
        except Exception as error:
            print('Activation failed:', error)

    result = license_service.verify()
    if not result.get('allowed'):
        print('Blocked:', result.get('reason', 'Verification failed'))
        return

    print('License verified. App can continue.')


if __name__ == '__main__':
    main()
