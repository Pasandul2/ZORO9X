from .client import activate, startup_guard


def activate_license_key(activation_key: str):
    return activate(activation_key)


def run_startup_guard():
    return startup_guard()
