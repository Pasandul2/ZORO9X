from .bridge import activate_license_key, run_startup_guard


class LicenseService:
    def activate(self, activation_key: str):
        return activate_license_key(activation_key)

    def verify(self):
        return run_startup_guard()
