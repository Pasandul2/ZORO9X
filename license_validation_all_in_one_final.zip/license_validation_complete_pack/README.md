License Validation Complete Pack

This package is ready to copy into any Python project.

Contents
- `license_manager/` reusable license validation module
- `requirements.txt` dependency list for this module
- `integration_example.py` simple usage example
- `.env.example` optional environment configuration

Quick setup in any project
1. Copy `license_manager/` into your project root.
2. Install dependency: `pip install -r requirements.txt` or install `requests`.
3. In your app, import service:
   - `from license_manager import LicenseService`
4. Use service:
   - `license_service = LicenseService()`
   - `license_service.activate('YOUR-KEY')`
   - `license_service.verify()`

Backend API expected
- `POST /api/licenses/activate`
- `POST /api/licenses/validate`

Environment variables (optional)
- `LICENSE_API_BASE` default: `http://localhost:4500`
- `LOCAL_LICENSE_FILE` custom license state path
