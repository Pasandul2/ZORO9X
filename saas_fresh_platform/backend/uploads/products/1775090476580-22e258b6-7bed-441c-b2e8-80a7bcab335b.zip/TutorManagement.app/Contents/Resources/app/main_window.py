from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


APP_STYLES = """
QMainWindow, QWidget {
    background: #f5f7fb;
    color: #102033;
    font-family: 'Helvetica Neue', Arial, sans-serif;
}
QFrame#Sidebar {
    background: #0f172a;
    border: none;
}
QFrame#TopBar {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QFrame#Card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QLabel#Title {
    font-size: 26px;
    font-weight: 700;
    color: #0f172a;
}
QLabel#Subtitle {
    font-size: 13px;
    color: #64748b;
}
QPushButton#NavButton {
    background: transparent;
    color: #e2e8f0;
    border: none;
    text-align: left;
    padding: 12px 14px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 600;
}
QPushButton#NavButton:hover {
    background: #1e293b;
}
QPushButton#NavButtonActive {
    background: #2563eb;
    color: #ffffff;
    border: none;
    text-align: left;
    padding: 12px 14px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
}
QPushButton#PrimaryButton {
    background: #2563eb;
    color: #ffffff;
    border: none;
    border-radius: 10px;
    padding: 10px 14px;
    font-weight: 600;
}
QPushButton#PrimaryButton:hover {
    background: #1d4ed8;
}
QPushButton#GhostButton {
    background: #e2e8f0;
    color: #0f172a;
    border: none;
    border-radius: 10px;
    padding: 10px 14px;
    font-weight: 600;
}
QPushButton#GhostButton:hover {
    background: #cbd5e1;
}
QLineEdit, QComboBox {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 9px 10px;
}
QTableWidget {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    gridline-color: #e2e8f0;
    selection-background-color: #dbeafe;
    selection-color: #0f172a;
}
QHeaderView::section {
    background: #f8fafc;
    color: #334155;
    padding: 10px;
    border: none;
    border-bottom: 1px solid #e2e8f0;
    font-weight: 700;
}
"""


@dataclass
class MetricData:
    label: str
    value: str
    hint: str


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Tutor Management Qt6')
        self.setMinimumSize(1280, 780)

        self.nav_buttons: dict[str, QPushButton] = {}
        self.pages = QStackedWidget()

        self.dashboard_page = self._build_dashboard_page()
        self.students_page = self._build_students_page()
        self.tutors_page = self._build_tutors_page()
        self.classes_page = self._build_classes_page()
        self.schedule_page = self._build_schedule_page()
        self.settings_page = self._build_settings_page()

        self.pages.addWidget(self.dashboard_page)
        self.pages.addWidget(self.students_page)
        self.pages.addWidget(self.tutors_page)
        self.pages.addWidget(self.classes_page)
        self.pages.addWidget(self.schedule_page)
        self.pages.addWidget(self.settings_page)

        root = QWidget()
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = self._build_sidebar()
        outer.addWidget(sidebar, 0)
        outer.addWidget(self._build_content_area(), 1)

        self.setCentralWidget(root)
        self.setStyleSheet(APP_STYLES)
        self._set_page('dashboard')
        self._load_sample_data()

    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName('Sidebar')
        sidebar.setFixedWidth(260)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 22, 18, 22)
        layout.setSpacing(10)

        brand = QLabel('TutorFlow')
        brand.setStyleSheet('color: #ffffff; font-size: 24px; font-weight: 800;')
        layout.addWidget(brand)

        tagline = QLabel('Tutor management dashboard')
        tagline.setStyleSheet('color: #94a3b8; font-size: 12px;')
        layout.addWidget(tagline)

        layout.addSpacing(14)
        layout.addWidget(self._nav_button('Dashboard', 'dashboard', active=True))
        layout.addWidget(self._nav_button('Students', 'students'))
        layout.addWidget(self._nav_button('Tutors', 'tutors'))
        layout.addWidget(self._nav_button('Classes', 'classes'))
        layout.addWidget(self._nav_button('Schedule', 'schedule'))
        layout.addWidget(self._nav_button('Settings', 'settings'))

        layout.addStretch(1)

        help_card = QFrame()
        help_card.setObjectName('Card')
        help_layout = QVBoxLayout(help_card)
        help_layout.setContentsMargins(14, 14, 14, 14)
        help_layout.setSpacing(8)

        help_title = QLabel('Quick Tip')
        help_title.setStyleSheet('font-size: 14px; font-weight: 700; color: #0f172a;')
        help_layout.addWidget(help_title)

        help_text = QLabel('Use the side menu to switch modules and manage your tutor data.')
        help_text.setWordWrap(True)
        help_text.setStyleSheet('font-size: 12px; color: #475569;')
        help_layout.addWidget(help_text)
        layout.addWidget(help_card)
        return sidebar

    def _build_content_area(self) -> QWidget:
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(22, 22, 22, 22)
        layout.setSpacing(18)

        topbar = QFrame()
        topbar.setObjectName('TopBar')
        top_layout = QHBoxLayout(topbar)
        top_layout.setContentsMargins(18, 16, 18, 16)
        top_layout.setSpacing(14)

        title_box = QVBoxLayout()
        self.title_label = QLabel('Dashboard')
        self.title_label.setObjectName('Title')
        self.subtitle_label = QLabel('Overview of students, tutors, classes, and schedules.')
        self.subtitle_label.setObjectName('Subtitle')
        title_box.addWidget(self.title_label)
        title_box.addWidget(self.subtitle_label)
        top_layout.addLayout(title_box)
        top_layout.addStretch(1)

        search = QLineEdit()
        search.setPlaceholderText('Search records...')
        search.setFixedWidth(320)
        top_layout.addWidget(search)

        layout.addWidget(topbar)
        layout.addWidget(self.pages, 1)
        return content

    def _build_nav_button(self, text: str, page_name: str, active: bool = False) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName('NavButtonActive' if active else 'NavButton')
        button.clicked.connect(lambda: self._set_page(page_name))
        self.nav_buttons[page_name] = button
        return button

    def _nav_button(self, text: str, page_name: str, active: bool = False) -> QPushButton:
        return self._build_nav_button(text, page_name, active)

    def _set_page(self, page_name: str) -> None:
        page_map = {
            'dashboard': 0,
            'students': 1,
            'tutors': 2,
            'classes': 3,
            'schedule': 4,
            'settings': 5,
        }
        self.pages.setCurrentIndex(page_map[page_name])
        labels = {
            'dashboard': ('Dashboard', 'Overview of students, tutors, classes, and schedules.'),
            'students': ('Students', 'Add, search, and manage student records.'),
            'tutors': ('Tutors', 'Track tutor profiles, subjects, and availability.'),
            'classes': ('Classes', 'Organize class batches and course assignments.'),
            'schedule': ('Schedule', 'Plan sessions and timetable slots.'),
            'settings': ('Settings', 'Configure the application and defaults.'),
        }
        self.title_label.setText(labels[page_name][0])
        self.subtitle_label.setText(labels[page_name][1])

        for name, button in self.nav_buttons.items():
            button.setObjectName('NavButtonActive' if name == page_name else 'NavButton')
            button.style().unpolish(button)
            button.style().polish(button)

    def _card(self, title: str, value: str, hint: str) -> QFrame:
        frame = QFrame()
        frame.setObjectName('Card')
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(8)

        title_label = QLabel(title)
        title_label.setStyleSheet('font-size: 13px; color: #64748b; font-weight: 600;')
        value_label = QLabel(value)
        value_label.setStyleSheet('font-size: 28px; font-weight: 800; color: #0f172a;')
        hint_label = QLabel(hint)
        hint_label.setWordWrap(True)
        hint_label.setStyleSheet('font-size: 12px; color: #64748b;')

        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(hint_label)
        return frame

    def _build_dashboard_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(16)

        metrics = QGridLayout()
        metrics.setSpacing(14)
        metrics.addWidget(self._card('Students', '128', 'Active students enrolled this term.'), 0, 0)
        metrics.addWidget(self._card('Tutors', '24', 'Available tutors across departments.'), 0, 1)
        metrics.addWidget(self._card('Classes', '18', 'Running class batches and sessions.'), 0, 2)
        metrics.addWidget(self._card('Today\'s Sessions', '9', 'Sessions scheduled for the current day.'), 0, 3)
        layout.addLayout(metrics)

        lower = QHBoxLayout()
        lower.setSpacing(16)

        activity_card = QFrame()
        activity_card.setObjectName('Card')
        activity_layout = QVBoxLayout(activity_card)
        activity_layout.setContentsMargins(18, 18, 18, 18)
        activity_layout.setSpacing(12)

        activity_title = QLabel('Recent Activity')
        activity_title.setStyleSheet('font-size: 18px; font-weight: 700; color: #0f172a;')
        activity_layout.addWidget(activity_title)

        self.activity_table = QTableWidget(5, 3)
        self.activity_table.setHorizontalHeaderLabels(['Time', 'Module', 'Details'])
        self.activity_table.verticalHeader().setVisible(False)
        self.activity_table.setAlternatingRowColors(True)
        self.activity_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.activity_table.horizontalHeader().setStretchLastSection(True)
        activity_layout.addWidget(self.activity_table)

        lower.addWidget(activity_card, 2)

        shortcut_card = QFrame()
        shortcut_card.setObjectName('Card')
        shortcut_layout = QVBoxLayout(shortcut_card)
        shortcut_layout.setContentsMargins(18, 18, 18, 18)
        shortcut_layout.setSpacing(10)

        shortcut_title = QLabel('Quick Actions')
        shortcut_title.setStyleSheet('font-size: 18px; font-weight: 700; color: #0f172a;')
        shortcut_layout.addWidget(shortcut_title)

        for label in ['Add Student', 'Add Tutor', 'Create Class', 'Plan Schedule']:
            button = QPushButton(label)
            button.setObjectName('GhostButton')
            button.clicked.connect(lambda checked=False, text=label: self._show_quick_action(text))
            shortcut_layout.addWidget(button)

        shortcut_layout.addStretch(1)
        lower.addWidget(shortcut_card, 1)

        layout.addLayout(lower)
        return page

    def _build_students_page(self) -> QWidget:
        return self._build_management_page(
            'Students',
            'Manage student records, contacts, and enrollment status.',
            ['Student ID', 'Name', 'Grade', 'Contact', 'Status'],
            [
                ['ST-1001', 'Aarav Perera', 'Grade 10', '077 123 4567', 'Active'],
                ['ST-1002', 'Nimasha Silva', 'Grade 11', '077 234 5678', 'Active'],
                ['ST-1003', 'Kasun Fernando', 'Grade 9', '077 345 6789', 'Pending'],
            ],
        )

    def _build_tutors_page(self) -> QWidget:
        return self._build_management_page(
            'Tutors',
            'Track tutor profiles, subjects, and teaching availability.',
            ['Tutor ID', 'Name', 'Subject', 'Availability', 'Rating'],
            [
                ['TU-2001', 'Madhawa', 'Mathematics', 'Mon-Fri', '4.9'],
                ['TU-2002', 'Ishara', 'Science', 'Tue-Sat', '4.8'],
                ['TU-2003', 'Dilan', 'English', 'Weekends', '4.7'],
            ],
        )

    def _build_classes_page(self) -> QWidget:
        return self._build_management_page(
            'Classes',
            'Organize class batches, subjects, and room assignments.',
            ['Class ID', 'Subject', 'Tutor', 'Batch', 'Room'],
            [
                ['CL-3001', 'Mathematics', 'Madhawa', 'A', 'Room 2'],
                ['CL-3002', 'Science', 'Ishara', 'B', 'Room 5'],
                ['CL-3003', 'English', 'Dilan', 'C', 'Lab 1'],
            ],
        )

    def _build_schedule_page(self) -> QWidget:
        return self._build_management_page(
            'Schedule',
            'Plan class sessions and timetable slots with room allocations.',
            ['Day', 'Start', 'End', 'Class', 'Room'],
            [
                ['Monday', '08:00', '10:00', 'Mathematics', 'Room 2'],
                ['Tuesday', '10:00', '12:00', 'Science', 'Room 5'],
                ['Saturday', '14:00', '16:00', 'English', 'Lab 1'],
            ],
        )

    def _build_settings_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(16)

        intro = QFrame()
        intro.setObjectName('Card')
        intro_layout = QVBoxLayout(intro)
        intro_layout.setContentsMargins(18, 18, 18, 18)
        intro_layout.setSpacing(10)

        title = QLabel('Application Settings')
        title.setStyleSheet('font-size: 18px; font-weight: 700; color: #0f172a;')
        intro_layout.addWidget(title)

        desc = QLabel('Configure the visible defaults for the tutor management app.')
        desc.setStyleSheet('font-size: 13px; color: #64748b;')
        intro_layout.addWidget(desc)

        theme_row = QHBoxLayout()
        theme_label = QLabel('Theme')
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(['Blue Modern', 'Light Minimal', 'Dark Slate'])
        theme_row.addWidget(theme_label)
        theme_row.addWidget(self.theme_combo, 1)
        intro_layout.addLayout(theme_row)

        save_button = QPushButton('Save Settings')
        save_button.setObjectName('PrimaryButton')
        save_button.clicked.connect(lambda: QMessageBox.information(self, 'Settings', 'Settings saved successfully.'))
        intro_layout.addWidget(save_button)

        layout.addWidget(intro)
        layout.addStretch(1)
        return page

    def _build_management_page(
        self,
        section_name: str,
        section_description: str,
        headers: Iterable[str],
        rows: Iterable[Iterable[str]],
    ) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(16)

        top = QFrame()
        top.setObjectName('Card')
        top_layout = QHBoxLayout(top)
        top_layout.setContentsMargins(18, 18, 18, 18)

        text_box = QVBoxLayout()
        heading = QLabel(section_name)
        heading.setStyleSheet('font-size: 18px; font-weight: 700; color: #0f172a;')
        detail = QLabel(section_description)
        detail.setStyleSheet('font-size: 13px; color: #64748b;')
        text_box.addWidget(heading)
        text_box.addWidget(detail)
        top_layout.addLayout(text_box)
        top_layout.addStretch(1)

        add_button = QPushButton(f'Add {section_name[:-1] if section_name.endswith("s") else section_name}')
        add_button.setObjectName('PrimaryButton')
        add_button.clicked.connect(lambda: self._show_quick_action(f'Add {section_name}'))
        top_layout.addWidget(add_button)

        layout.addWidget(top)

        body = QHBoxLayout()
        body.setSpacing(16)

        form_card = QFrame()
        form_card.setObjectName('Card')
        form_layout = QVBoxLayout(form_card)
        form_layout.setContentsMargins(18, 18, 18, 18)
        form_layout.setSpacing(10)

        form_title = QLabel('Quick Entry Form')
        form_title.setStyleSheet('font-size: 16px; font-weight: 700; color: #0f172a;')
        form_layout.addWidget(form_title)

        self.form_inputs = []
        for header in headers:
            label = QLabel(header)
            input_box = QLineEdit()
            input_box.setPlaceholderText(f'Enter {header.lower()}')
            form_layout.addWidget(label)
            form_layout.addWidget(input_box)
            self.form_inputs.append(input_box)

        submit = QPushButton('Save Record')
        submit.setObjectName('PrimaryButton')
        submit.clicked.connect(lambda: self._show_quick_action(f'Saved {section_name} record'))
        form_layout.addWidget(submit)

        body.addWidget(form_card, 1)

        table_card = QFrame()
        table_card.setObjectName('Card')
        table_layout = QVBoxLayout(table_card)
        table_layout.setContentsMargins(18, 18, 18, 18)
        table_layout.setSpacing(10)

        table_title = QLabel(f'{section_name} Records')
        table_title.setStyleSheet('font-size: 16px; font-weight: 700; color: #0f172a;')
        table_layout.addWidget(table_title)

        table = QTableWidget()
        table.setColumnCount(len(list(headers)))
        headers_list = list(headers)
        table.setHorizontalHeaderLabels(headers_list)
        table.setRowCount(len(list(rows)))
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.horizontalHeader().setStretchLastSection(True)

        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                table.setItem(row_index, column_index, QTableWidgetItem(value))

        table_layout.addWidget(table)
        body.addWidget(table_card, 2)
        layout.addLayout(body)
        return page

    def _load_sample_data(self) -> None:
        sample_rows = [
            ['08:45', 'Student', 'New student registration submitted'],
            ['09:10', 'Tutor', 'Tutor availability updated'],
            ['10:30', 'Class', 'Mathematics class batch created'],
            ['11:20', 'Schedule', 'Friday timetable adjusted'],
            ['13:05', 'System', 'Backup completed successfully'],
        ]
        for row_index, row in enumerate(sample_rows):
            for col_index, value in enumerate(row):
                self.activity_table.setItem(row_index, col_index, QTableWidgetItem(value))

    def _show_quick_action(self, message: str) -> None:
        QMessageBox.information(self, 'TutorFlow', message)
