import sys

from PyQt6.QtWidgets import QApplication, QInputDialog, QMessageBox

from app import MainWindow
from license_manager import LicenseService


def ensure_license_is_valid() -> bool:
    license_service = LicenseService()
    guard = license_service.verify()
    if guard.get('allowed'):
        return True

    while True:
        reason = guard.get('reason', 'License verification failed')
        choice = QMessageBox.question(
            None,
            'License Required',
            f'{reason}\n\nDo you want to activate a license now?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if choice == QMessageBox.StandardButton.No:
            return False

        activation_key, ok = QInputDialog.getText(None, 'Activate License', 'Enter activation key:')
        if not ok or not activation_key.strip():
            return False

        try:
            license_service.activate(activation_key.strip())
            guard = license_service.verify()
            if guard.get('allowed'):
                QMessageBox.information(None, 'Verified', 'License activated successfully.')
                return True
        except Exception as error:
            QMessageBox.critical(None, 'Activation Failed', str(error))


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName('Tutor Management Qt6')
    if not ensure_license_is_valid():
        QMessageBox.warning(None, 'Blocked', 'The app cannot start without a valid license.')
        return 1
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
