# Tutor Management Qt6 App

A modern Python Qt6 desktop GUI for managing tutors, students, classes, and schedules.

## License Manager Setup
This project includes a reusable `license_manager/` module and starts only after license verification succeeds.

Import pattern used by the app:
- `from license_manager import LicenseService`

License flow:
- Verify on startup
- Prompt for activation key if no local license exists
- Block the app when verification fails

## Features
- Modern dashboard UI
- Students, tutors, classes, and schedule screens
- Sample data tables and forms
- Responsive navigation sidebar

## Setup
1. Create a virtual environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python main.py
   ```

## macOS Runner
- Double-click or run `run_tutor_management.command` to install dependencies and launch the app.
- Use `package_tutor_management.command` to build a zip that includes the app and the embedded license manager.

If needed, make the scripts executable:
```bash
chmod +x run_tutor_management.command package_tutor_management.command
```

Optional environment variables:
- `LICENSE_API_BASE` - backend license API base URL
- `LOCAL_LICENSE_FILE` - custom path for the local license state file

## Project Structure
- `main.py` - application entry point
- `app/main_window.py` - main GUI implementation
- `app/__init__.py` - package marker
- `license_manager/` - embedded reusable license validation module

## Next Steps
- Connect to SQLite or MySQL
- Add CRUD save/load actions
- Add login and role permissions
